/**
 * 数据库的collection名称
 */
const collectionName = {
    "workConfig":"workConfig",               //系统配置
    "pcbcount":"pcbcount",                   //出料后存储产品信息
    "machineConfig":"machineConfig",         //机器配置,
    "productCount":"productCount"
};
module.exports = collectionName;