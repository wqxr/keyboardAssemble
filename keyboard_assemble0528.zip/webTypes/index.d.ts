declare function nodeRequire(nodeName: string): any;
declare let __dirname:string;