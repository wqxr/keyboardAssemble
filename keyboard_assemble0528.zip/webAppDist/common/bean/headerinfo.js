"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Headerinfo = /** @class */ (function () {
    function Headerinfo() {
        this.CT = 0;
        this.AOutTrayCount = 0;
        this.BOutTrayCount = 0;
        this.Acycletime = 0; //A装配周期时间
        this.Bcycletime = 0; //B装配周期时间
        this.AtrayStyle = false;
        this.BtrayStyle = false;
        this.headdetail = [];
    }
    return Headerinfo;
}());
exports.Headerinfo = Headerinfo;
//# sourceMappingURL=headerinfo.js.map