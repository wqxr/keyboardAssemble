"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Assembling = /** @class */ (function () {
    function Assembling() {
        this.keycaps = [];
        this.keycapsDetail = [];
        for (var i = 0; i <= 1; i++) {
            this.keycaps.push({
                language: "",
                machineType: "",
                type: "",
                color: "",
                station: "",
                SN: ""
            });
        }
        this.detailproduct = [];
    }
    return Assembling;
}());
exports.Assembling = Assembling;
var keycaps = /** @class */ (function () {
    function keycaps() {
    }
    return keycaps;
}());
var keycapsDetail = /** @class */ (function () {
    function keycapsDetail() {
    }
    return keycapsDetail;
}());
var productdetail = /** @class */ (function () {
    function productdetail() {
        this.index = 0;
    }
    return productdetail;
}());
exports.productdetail = productdetail;
//# sourceMappingURL=assembling.js.map