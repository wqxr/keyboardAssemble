"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Trayinfo = /** @class */ (function () {
    function Trayinfo() {
    }
    return Trayinfo;
}());
exports.Trayinfo = Trayinfo;
//# sourceMappingURL=trayinfo.js.map