"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var productDetail = /** @class */ (function () {
    function productDetail() {
        this.codeStation = "";
        this.APCBSN = "";
        this.ATraySN = "";
        this.BPCBSN = "";
        this.BTraySN = "";
        this.type = "";
        this.jobnumber = "";
        this.keynow = "";
    }
    return productDetail;
}());
exports.productDetail = productDetail;
//# sourceMappingURL=productdetail.js.map