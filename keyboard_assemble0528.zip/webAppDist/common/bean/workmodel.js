"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var workModel = /** @class */ (function () {
    function workModel() {
    }
    return workModel;
}());
exports.workModel = workModel;
var machineConnect = /** @class */ (function () {
    function machineConnect() {
        this.uiCnt = 0;
        this.pcbScannerCnt = 0;
        this.trayScannerCnt = 0;
        this.CCDCnt = 0;
        this.SFCconnect = 0;
    }
    return machineConnect;
}());
exports.machineConnect = machineConnect;
//# sourceMappingURL=workmodel.js.map