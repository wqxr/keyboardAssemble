"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * 定义请求消息格式
 */
var MessageRequest = /** @class */ (function () {
    function MessageRequest() {
    }
    return MessageRequest;
}());
exports.MessageRequest = MessageRequest;
/**
 * 定义相应消息格式
 */
var MessageResponse = /** @class */ (function () {
    function MessageResponse() {
    }
    return MessageResponse;
}());
exports.MessageResponse = MessageResponse;
//# sourceMappingURL=message.js.map