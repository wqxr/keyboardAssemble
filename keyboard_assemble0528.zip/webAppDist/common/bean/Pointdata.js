"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var pointdata = /** @class */ (function () {
    //输入，输出
    function pointdata(name, xpoint, ypoint, zpoint, total) {
        this.xpoint = xpoint;
        this.name = name;
        this.ypoint = ypoint;
        this.zpoint = zpoint;
        this.total = total;
    }
    return pointdata;
}());
exports.pointdata = pointdata;
var twopoint = /** @class */ (function () {
    function twopoint(index) {
        this.index = index;
        this.name = "";
        this.pointinfo = [];
    }
    return twopoint;
}());
exports.twopoint = twopoint;
exports.IOListC = [];
exports.IOListC1 = [];
exports.IOList = [];
exports.IOListA = [];
exports.IOListB = [];
exports.IOListB1 = [];
//export const objB:any[]=[];
// export class totalpoint{
//    public  Apoint:IOList;
//    //public  Bpoint:IOList;
// }
var tempItem = new twopoint(1);
tempItem.name = "CCD工站";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    new pointdata("A扫码位", 0, 0, 0, 1),
    new pointdata("A上下ENTER拍照位", 0, 0, 0, 1),
    new pointdata("B扫码位", 0, 0, 0, 1),
    new pointdata("B空格拍照位", 0, 0, 0, 1),
    new pointdata("B上下ENTER拍照位", 0, 0, 0, 1),
];
exports.IOListC[0] = tempItem;
exports.IOListC1[0] = Object.assign([], exports.IOListC[0]);
exports.IOListC1[0] = JSON.parse(JSON.stringify(exports.IOListC[0]));
// tempItem = new twopoint(2);
// tempItem.name="Tray运料";
// tempItem.pointinfo=[
//         new pointdata("取料位",0,0,0,1),
//         new pointdata("A放料位",0,0,0,1),
//         new pointdata("B放料位",0,0,0,1),
//         new pointdata("Caps键拍照位（jis）",0,0,0,1),
//         new pointdata("SPace键拍照位",0,0,0,1),
//         new pointdata("上下键拍照位",0,0,0,1),
// ]
// IOListC[1]=tempItem;
// IOListC1[1]=Object.assign([],IOListC[1]);
// IOListC1[1]=JSON.parse(JSON.stringify(IOListC[1]));
tempItem = new twopoint(4);
tempItem.name = "A-Tray顶升";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    new pointdata("出料位", 0, 0, 0, 1),
    new pointdata("间隙 ", 0, 0, 0, 1),
    new pointdata("最高点", 0, 0, 0, 1),
    new pointdata("第一层料盘位", 0, 0, 0, 1),
    new pointdata("料盘行终点", 0, 0, 0, 1),
];
exports.IOList[0] = tempItem;
exports.IOListA[0] = Object.assign([], exports.IOList[0]);
exports.IOListA[0] = JSON.parse(JSON.stringify(exports.IOList[0]));
tempItem = new twopoint(5);
tempItem.name = "A-取键帽";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 2),
    new pointdata("取tray盘位", 0, 0, 0, 2),
    //  new pointdata("取键帽位",0,0,0,2),
    //  new pointdata("取其他键位",0,0,0,2),
    new pointdata("取上下键帽位", 0, 0, 0, 2),
    new pointdata("取回车空格键帽位", 0, 0, 0, 2),
    new pointdata("放tray盘位", 0, 0, 0, 2),
    new pointdata("放UP键", 0, 0, 0, 2),
    new pointdata("放DOWN键", 0, 0, 0, 2),
    new pointdata("放空格键", 0, 0, 0, 2),
    new pointdata("放Enter键", 0, 0, 0, 2),
    new pointdata("放UP键_JIS", 0, 0, 0, 2),
    new pointdata("放DOWN键_JIS", 0, 0, 0, 2),
    new pointdata("放空格键_JIS", 0, 0, 0, 2),
    new pointdata("放ENTER键_JIS", 0, 0, 0, 2),
    new pointdata("放Caps键_JIS", 0, 0, 0, 2),
];
exports.IOList[1] = tempItem;
exports.IOListA[1] = Object.assign([], exports.IOList[1]);
exports.IOListA[1] = JSON.parse(JSON.stringify(exports.IOList[1]));
tempItem = new twopoint(6);
tempItem.name = "A-键帽导正";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    new pointdata("取料位", 0, 0, 0, 1),
    new pointdata("接料位", 0, 0, 0, 1),
];
exports.IOList[2] = tempItem;
exports.IOListA[2] = Object.assign([], exports.IOList[2]);
exports.IOListA[2] = JSON.parse(JSON.stringify(exports.IOList[2]));
tempItem = new twopoint(7);
tempItem.name = "A-扣合运料";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 3),
    //new pointdata("JIS取料位(5个键位)",0,0,0,0),
    new pointdata("上键取料位", 0, 0, 0, 3),
    new pointdata("下键取料位", 0, 0, 0, 3),
    // new pointdata("上下键取料位",0,0,0,3),
    new pointdata("ENTER键取料位", 0, 0, 0, 3),
    new pointdata("空格键取料位", 0, 0, 0, 3),
    new pointdata("空格键扣合位", 0, 0, 0, 3),
    new pointdata("上键扣合位", 0, 0, 0, 3),
    new pointdata("下键扣合位", 0, 0, 0, 3),
    new pointdata("ENTER扣合位", 0, 0, 0, 3),
    new pointdata("上键偏移_JIS", 0, 0, 0, 3),
    new pointdata("下键偏移_JIS", 0, 0, 0, 3),
    new pointdata("ENTER偏移_JIS", 0, 0, 0, 3),
    new pointdata("空格键偏移_JIS", 0, 0, 0, 3),
    new pointdata("上键偏移", 0, 0, 0, 3),
    new pointdata("下键偏移", 0, 0, 0, 3),
    new pointdata("ENTER键偏移", 0, 0, 0, 3),
    new pointdata("空格键偏移", 0, 0, 0, 3),
    new pointdata("上键取料位_JIS", 0, 0, 0, 3),
    new pointdata("下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键取料位_JIS", 0, 0, 0, 3),
    new pointdata("空格键取料位_JIS", 0, 0, 0, 3),
    new pointdata("Caps键取料位_JIS", 0, 0, 0, 3),
    new pointdata("空格扣合位_JIS", 0, 0, 0, 3),
    new pointdata("上键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("下键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("Caps键扣合位_JIS", 0, 0, 0, 3),
];
exports.IOList[3] = tempItem;
exports.IOListA[3] = Object.assign([], exports.IOList[3]);
exports.IOListA[3] = JSON.parse(JSON.stringify(exports.IOList[3]));
tempItem = new twopoint(8);
tempItem.name = "A-取PCB";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 2),
    new pointdata("取料位", 0, 0, 0, 2),
    new pointdata("放料位", 0, 0, 0, 2),
    new pointdata("微压料位", 0, 0, 0, 2),
    new pointdata("组装位", 0, 0, 0, 2),
    new pointdata("放料位_JIS", 0, 0, 0, 2),
    new pointdata("微压料位_JIS", 0, 0, 0, 2),
];
exports.IOList[5] = tempItem;
exports.IOListA[5] = Object.assign([], exports.IOList[5]);
exports.IOListA[5] = JSON.parse(JSON.stringify(exports.IOList[5]));
tempItem = new twopoint(9);
tempItem.name = "A-回车上下键扣合";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 3),
    new pointdata("ENTER键取料位", 0, 0, 0, 3),
    new pointdata("上键取料位", 0, 0, 0, 3),
    new pointdata("下键取料位", 0, 0, 0, 3),
    // new pointdata("ENTER键扣合偏移",0,0,0,3),
    //new pointdata("JIS取键位",0,0,0,3),
    new pointdata("上键扣合位", 0, 0, 0, 3),
    new pointdata("下键扣合位", 0, 0, 0, 3),
    new pointdata("上下键取料位", 0, 0, 0, 3),
    //new pointdata("上键扣合偏移",0,0,0,3),
    // new pointdata("下键扣合偏移",0,0,0,3),
    new pointdata("ENTER键扣合位", 0, 0, 0, 3),
    new pointdata("ENTER键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("下键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键扣合位_JIS", 0, 0, 0, 3),
];
exports.IOList[4] = tempItem;
exports.IOListA[4] = Object.assign([], exports.IOList[4]);
exports.IOListA[4] = JSON.parse(JSON.stringify(exports.IOList[4]));
tempItem = new twopoint(10);
tempItem.name = "A-空格CAPS扣合";
tempItem.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    // new pointdata("JIS取料位",0,0,0,1),
    // new pointdata("SPACE取料位",0,0,0,1),
    new pointdata("Caps键取料位", 0, 0, 0, 1),
    new pointdata("Caps键扣合位", 0, 0, 0, 1),
];
exports.IOList[6] = tempItem;
exports.IOListA[6] = Object.assign([], exports.IOList[6]);
exports.IOListA[6] = JSON.parse(JSON.stringify(exports.IOList[6]));
var tempItem1 = new twopoint(12);
tempItem1.name = "B-tray顶升";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    new pointdata("出料位", 0, 0, 0, 1),
    new pointdata("间隙", 0, 0, 0, 1),
    new pointdata("最高点", 0, 0, 0, 1),
    new pointdata("第一层料盘高度", 0, 0, 0, 1),
];
exports.IOListB[0] = tempItem1;
exports.IOListB1[0] = Object.assign([], tempItem1);
exports.IOListB1[0] = JSON.parse(JSON.stringify(exports.IOListB[0]));
tempItem1 = new twopoint(13);
tempItem1.name = "B-取键帽";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 2),
    new pointdata("取tray盘位", 0, 0, 0, 2),
    //  new pointdata("取键帽位",0,0,0,2),
    //  new pointdata("取其他键位",0,0,0,2),
    new pointdata("取上下键帽位", 0, 0, 0, 2),
    new pointdata("取回车空格键位", 0, 0, 0, 2),
    new pointdata("放tray盘位", 0, 0, 0, 2),
    new pointdata("放UP键", 0, 0, 0, 2),
    new pointdata("放DOWN键", 0, 0, 0, 2),
    new pointdata("放空格键", 0, 0, 0, 2),
    new pointdata("放Enter键", 0, 0, 0, 2),
    new pointdata("放UP键_JIS", 0, 0, 0, 2),
    new pointdata("放DOWN键_JIS", 0, 0, 0, 2),
    new pointdata("放空格键_JIS", 0, 0, 0, 2),
    new pointdata("放Enter键_JIS", 0, 0, 0, 2),
    new pointdata("放Caps键_JIS", 0, 0, 0, 2),
];
exports.IOListB[1] = tempItem1;
exports.IOListB1[1] = Object.assign([], tempItem1);
exports.IOListB1[1] = JSON.parse(JSON.stringify(exports.IOListB[1]));
tempItem1 = new twopoint(14);
tempItem1.name = "B-键帽导正";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    new pointdata("取料位", 0, 0, 0, 1),
    new pointdata("接料位", 0, 0, 0, 1),
];
exports.IOListB[2] = tempItem1;
exports.IOListB1[2] = Object.assign([], tempItem1);
exports.IOListB1[2] = JSON.parse(JSON.stringify(exports.IOListB[2]));
tempItem1 = new twopoint(15);
tempItem1.name = "B-扣合运料";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 3),
    //new pointdata("JIS取料位(5个键位)",0,0,0,0),
    new pointdata("上键取料位", 0, 0, 0, 3),
    new pointdata("下键取料位", 0, 0, 0, 3),
    // new pointdata("上下键取料位",0,0,0,3),
    new pointdata("ENTER键取料位", 0, 0, 0, 3),
    new pointdata("空格键取料位", 0, 0, 0, 3),
    new pointdata("空格键扣合位", 0, 0, 0, 3),
    new pointdata("上键扣合位", 0, 0, 0, 3),
    new pointdata("下键扣合位", 0, 0, 0, 3),
    new pointdata("ENTER键扣合位", 0, 0, 0, 3),
    new pointdata("上键偏移_JIS", 0, 0, 0, 3),
    new pointdata("下键偏移_JIS", 0, 0, 0, 3),
    new pointdata("ENTER偏移_JIS", 0, 0, 0, 3),
    new pointdata("空格键偏移_JIS", 0, 0, 0, 3),
    new pointdata("上键偏移", 0, 0, 0, 3),
    new pointdata("下键偏移", 0, 0, 0, 3),
    new pointdata("ENTER偏移", 0, 0, 0, 3),
    new pointdata("空格键偏移", 0, 0, 0, 3),
    new pointdata("上键取料位_JIS", 0, 0, 0, 3),
    new pointdata("下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键取料位_JIS", 0, 0, 0, 3),
    new pointdata("空格键取料位_JIS", 0, 0, 0, 3),
    new pointdata("Caps键取料位_JIS", 0, 0, 0, 3),
    new pointdata("空格键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("上键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("下键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("Caps键扣合位_JIS", 0, 0, 0, 3),
];
exports.IOListB[3] = tempItem1;
exports.IOListB1[3] = Object.assign([], tempItem1);
exports.IOListB1[3] = JSON.parse(JSON.stringify(exports.IOListB[3]));
tempItem1 = new twopoint(16);
tempItem1.name = "B-取PCB";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 2),
    new pointdata("取料位", 0, 0, 0, 2),
    new pointdata("放料位", 0, 0, 0, 2),
    new pointdata("微压料位", 0, 0, 0, 2),
    new pointdata("组装位", 0, 0, 0, 2),
    new pointdata("放料位_JIS", 0, 0, 0, 2),
    new pointdata("微压料位_JIS", 0, 0, 0, 2),
];
exports.IOListB[5] = tempItem1;
exports.IOListB1[5] = Object.assign([], tempItem1);
tempItem1 = new twopoint(17);
tempItem1.name = "B-回车上下键扣合";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 3),
    new pointdata("ENTER键取料位", 0, 0, 0, 3),
    new pointdata("上键取料位", 0, 0, 0, 3),
    new pointdata("下键取料位", 0, 0, 0, 3),
    // new pointdata("ENTER键扣合偏移",0,0,0,3),
    //new pointdata("JIS取键位",0,0,0,3),
    new pointdata("上键扣合位", 0, 0, 0, 3),
    new pointdata("下键扣合位", 0, 0, 0, 3),
    new pointdata("上下键取料位", 0, 0, 0, 3),
    //new pointdata("上键扣合偏移",0,0,0,3),
    // new pointdata("下键扣合偏移",0,0,0,3),
    new pointdata("ENTER键扣合位", 0, 0, 0, 3),
    new pointdata("ENTER键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("下键取料位_JIS", 0, 0, 0, 3),
    new pointdata("上键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("下键扣合位_JIS", 0, 0, 0, 3),
    new pointdata("ENTER键扣合位_JIS", 0, 0, 0, 3),
];
exports.IOListB[4] = tempItem1;
exports.IOListB1[4] = Object.assign([], tempItem1);
exports.IOListB1[4] = JSON.parse(JSON.stringify(exports.IOListB[4]));
tempItem1 = new twopoint(18);
tempItem1.name = "B-空格caps扣合";
tempItem1.pointinfo = [
    new pointdata("起始位", 0, 0, 0, 1),
    // new pointdata("JIS取料位",0,0,0,1),
    // new pointdata("SPACE取料位",0,0,0,1),
    new pointdata("Caps键取料位", 0, 0, 0, 1),
    new pointdata("Caps键扣合位", 0, 0, 0, 1),
];
exports.IOListB[6] = tempItem1;
exports.IOListB1[6] = Object.assign([], tempItem1);
exports.IOListB1[6] = JSON.parse(JSON.stringify(exports.IOListB[6]));
//# sourceMappingURL=Pointdata.js.map