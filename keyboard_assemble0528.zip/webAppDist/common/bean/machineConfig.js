"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Config = /** @class */ (function () {
    function Config() {
        this.IP = "";
        this.MAC_ADDR = "";
        this.LineNo = "";
        this.StationNo = "";
        this.MachineNo = "";
        this.StationVer = "";
        this.OutTrayCount = "";
    }
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=machineConfig.js.map