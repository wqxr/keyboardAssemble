"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/// <reference path="../../../webTypes/index.d.ts"/>
var core_1 = require("@angular/core");
var msgType_1 = require("../bean/msgType");
var ipcRenderer = nodeRequire('electron').ipcRenderer;
var IPCService = /** @class */ (function () {
    function IPCService() {
        var _this = this;
        this.callBackArray = [];
        var listener = function (event, params) {
            var data = params;
            //console.log(data);
            var list = _this.callBackArray.filter(function (item) {
                return item.msgType === data.msgType;
            });
            list.forEach(function (callbackItem) {
                callbackItem.callBack(data);
            });
        };
        ipcRenderer.on(msgType_1.MSG_TYPE.SEND_TO_PAGE, listener);
        // let msg = {
        //     "msgType": "getAllHWOType",
        //     "version": "v1.0.0",
        //     "timestamp": "2017-08-11 09:24:54 257",
        //     "data": {value:"hahahha"},
        //     "msgId": "F20803CD-9FF6-4ABD-9CBB-CE531AD652F2"
        // };
        // setInterval(function(){
        //     ipcRenderer.send("MID_MSG","哈哈哈哈哈");
        // },3000);
    }
    IPCService.prototype.send = function (msgType, data) {
        ipcRenderer.send(msgType_1.MSG_TYPE.SEND_TO_MID, {
            msgType: msgType,
            data: data
        });
        // let listener=function(event:any,params:any){
        //         msg.data=params.data;
        //         msg.msgId=params.msgId;
        //         msg.msgType=params.msgType;
        //         msg.timestamp=params.timestamp;
        //         msg.version=params.version;
        //       return new Promise(function(resolve,reject){
        //         if(params!==""){
        //             resolve(msg);
        //         }else{
        //             reject("没有数据");
        //         }
        // });         
        // }
        //    ipcRenderer.on("test",listener);
    };
    IPCService.prototype.on = function (msgType, callback) {
        this.callBackArray.push({
            msgType: msgType,
            callBack: callback
        });
    };
    ;
    IPCService.prototype.off = function (msgType, callback) {
        var list = this.callBackArray.filter(function (item) {
            return item.msgType != msgType;
        });
        this.callBackArray = list;
    };
    IPCService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], IPCService);
    return IPCService;
}());
exports.IPCService = IPCService;
var listenerList = /** @class */ (function () {
    function listenerList() {
    }
    return listenerList;
}());
//let t = new IPCService();
//let callbackA = function(){};
//let callbackB = function(){};
//t.on("AAA",callbackA);
// t.on("AAA",callbackB);
// t.off("AAA");
// t.off("AAA",callbackA);
// page node c++
// require('electron').ipcRenderer.on('ping', function(event, message){
//                     console.log(message);
//# sourceMappingURL=ipc.service.js.map