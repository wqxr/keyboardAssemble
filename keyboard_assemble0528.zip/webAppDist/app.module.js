"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var root_1 = require("./component/root/root");
var headerinfo_1 = require("./component/headerinfo/headerinfo");
var forms_1 = require("@angular/forms");
var assembleing_1 = require("./component/assembleing/assembleing");
var keycaps_1 = require("./component/keycaps/keycaps");
var aside_1 = require("./component/aside/aside");
var configpanel_1 = require("./component/configPanel/configpanel");
var logPanel_1 = require("./component/logPanel/logPanel");
var pointPanel_1 = require("./component/pointPanel/pointPanel");
var login_panel_1 = require("./component/loginPanel/login.panel");
var change_password_1 = require("./component/changePassword/change.password");
var stationB_1 = require("./component/stationB/stationB");
var stationA_1 = require("./component/stationA/stationA");
var pointOutmaterial_1 = require("./component/OutmaterialPoint/pointOutmaterial");
var keycapsdetail_1 = require("./component/keycapsDetails/keycapsdetail");
var pcbcount_1 = require("./component/pcbcount/pcbcount");
var ipc_service_1 = require("./common/service/ipc.service");
var countinfoService_1 = require("./service/countinfoService");
var assemblingService_1 = require("./service/assemblingService");
var assemblystatusService_1 = require("./service/assemblystatusService");
var TrayinfoService_1 = require("./service/TrayinfoService");
var productionRecordService_1 = require("./service/productionRecordService");
var io_service_1 = require("./service/io.service");
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [
                platform_browser_1.BrowserModule,
                forms_1.FormsModule,
            ],
            declarations: [
                root_1.AppComponent,
                headerinfo_1.HeaderinfoComponent,
                assembleing_1.AssembleinfoComponent,
                keycaps_1.KeycapsComponent,
                keycapsdetail_1.KeycapDetailComponent,
                aside_1.AsideComponent,
                configpanel_1.Configpanel,
                logPanel_1.LogPanel,
                pointPanel_1.PointPanel,
                stationB_1.StationB,
                stationA_1.StationA,
                login_panel_1.LoginlPanel,
                change_password_1.ChangePassword,
                pcbcount_1.PcbCountComponent,
                pointOutmaterial_1.outmaterialPoint
            ],
            providers: [
                ipc_service_1.IPCService,
                countinfoService_1.countInfoService,
                assemblingService_1.AssemblingService,
                assemblystatusService_1.assemblystatusService,
                TrayinfoService_1.TrayinfoService,
                productionRecordService_1.productionRecordService,
                io_service_1.IOService
            ],
            bootstrap: [root_1.AppComponent]
        })
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map