// import './polyfills';
// import { platformBrowser  } from '@angular/platform-browser';
// import { AppModuleNgFactory  } from '../aot/webApp/app.module.ngfactory';
// platformBrowser().bootstrapModuleFactory(AppModuleNgFactory); 
//# sourceMappingURL=bootstrap.js.map