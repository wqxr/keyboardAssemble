"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Pointdata_1 = require("../../common/bean/Pointdata");
var ipc_service_1 = require("../../common/service/ipc.service");
var StationA = /** @class */ (function () {
    function StationA(_ngZone, ipcService) {
        this.isShow = true;
        this.iOList = Pointdata_1.IOList;
        this.IOListAold = Pointdata_1.IOListA;
        this.ioisShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
    }
    StationA.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("getPoint", function (data) {
            _this._ngZone.run(function () {
                _this.getPointfun(data.data.station, data.data.xPoint, data.data.yPoint, data.data.zPoint, data.data.pointname);
            });
        });
    };
    StationA.prototype.onclose = function () {
        this.ioisShow.emit(this.isShow);
    };
    StationA.prototype.changedata = function () {
    };
    StationA.prototype.getPointfun = function (station, xPoint, yPoint, zPoint, name) {
        for (var i = 0; i < this.iOList.length; i++) {
            if (this.iOList[i].index === station) {
                var pointinfo = this.iOList[i].pointinfo;
                var pointinfoold = this.IOListAold[i].pointinfo;
                for (var j = 0; j < pointinfo.length; j++) {
                    if (pointinfo[j].name == name) {
                        pointinfo[j].xpoint = xPoint;
                        pointinfo[j].ypoint = yPoint;
                        pointinfo[j].zpoint = zPoint;
                        pointinfoold[j].xpoint = xPoint;
                        pointinfoold[j].ypoint = yPoint;
                        pointinfoold[j].zpoint = zPoint;
                    }
                }
            }
        }
    };
    StationA.prototype.savePoint = function () {
        for (var i = 0; i < this.iOList.length; i++) {
            for (var j = 0; j < this.iOList[i].pointinfo.length; j++) {
                if (this.iOList[i].pointinfo[j].xpoint !== this.IOListAold[i].pointinfo[j].xpoint) {
                    var stationid = this.iOList[i].index;
                    var stationname = this.iOList[i].name;
                    var name_1 = this.iOList[i].pointinfo[j].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_1, "xPoint": this.iOList[i].pointinfo[j].xpoint, "yPoint": this.iOList[i].pointinfo[j].ypoint, "zPoint": this.iOList[i].pointinfo[j].zpoint, "prexpoint": this.IOListAold[i].pointinfo[j].xpoint, "totalpoint": this.iOList[i].pointinfo[j].total, "change": "x" });
                    this.IOListAold[i].pointinfo[j].xpoint = this.iOList[i].pointinfo[j].xpoint;
                }
                if (this.iOList[i].pointinfo[j].ypoint !== this.IOListAold[i].pointinfo[j].ypoint) {
                    var stationid = this.iOList[i].index;
                    var name_2 = this.iOList[i].pointinfo[j].name;
                    var stationname = this.iOList[i].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_2, "xPoint": this.iOList[i].pointinfo[j].xpoint, "yPoint": this.iOList[i].pointinfo[j].ypoint, "zPoint": this.iOList[i].pointinfo[j].zpoint, "prexpoint": this.IOListAold[i].pointinfo[j].ypoint, "totalpoint": this.iOList[i].pointinfo[j].total, "change": "y" });
                    this.IOListAold[i].pointinfo[j].ypoint = this.iOList[i].pointinfo[j].ypoint;
                }
                if (this.iOList[i].pointinfo[j].zpoint !== this.IOListAold[i].pointinfo[j].zpoint) {
                    var stationid = this.iOList[i].index;
                    var name_3 = this.iOList[i].pointinfo[j].name;
                    var stationname = this.iOList[i].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_3, "xPoint": this.iOList[i].pointinfo[j].xpoint, "yPoint": this.iOList[i].pointinfo[j].ypoint, "zPoint": this.iOList[i].pointinfo[j].zpoint, "prexpoint": this.IOListAold[i].pointinfo[j].zpoint, "totalpoint": this.iOList[i].pointinfo[j].total, "change": "z" });
                    this.IOListAold[i].pointinfo[j].zpoint = this.iOList[i].pointinfo[j].zpoint;
                }
            }
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], StationA.prototype, "machinestatus", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], StationA.prototype, "userrole", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationA.prototype, "ioisShow", void 0);
    StationA = __decorate([
        core_1.Component({
            selector: 'station-a',
            templateUrl: "./webApp/component/stationA/stationA.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], StationA);
    return StationA;
}());
exports.StationA = StationA;
//# sourceMappingURL=stationA.js.map