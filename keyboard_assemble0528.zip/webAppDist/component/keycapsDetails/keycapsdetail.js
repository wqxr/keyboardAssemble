"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var productdetail_1 = require("../../common/bean/productdetail");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var KeycapDetailComponent = /** @class */ (function () {
    function KeycapDetailComponent(_ngZone, ipcService) {
        this._ngZone = _ngZone;
        this.ipcService = ipcService;
        this.handerUploadConfig = {
            code: "",
            TraySN: "",
            PCBSN: "",
            operatorType: "" // 1 pcb查询 2 Tray盘上传 3 PCB上传  
        };
    }
    //pcb查询
    KeycapDetailComponent.prototype.pcbSearch = function () {
        if (this.status == "工作中") {
            return;
        }
        if (this.assembling.APCBSN === "" && this.assembling.BPCBSN === "") {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "SN不能为空",
            });
            return;
        }
        if (this.assembling.APCBSN !== undefined && this.assembling.APCBSN !== "") {
            this.handerUploadConfig.code = "A";
            this.handerUploadConfig.TraySN = this.assembling.ATraySN;
            this.handerUploadConfig.PCBSN = this.assembling.APCBSN;
            this.handerUploadConfig.operatorType = "pcb_check";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
        if (this.assembling.BPCBSN !== undefined && this.assembling.BPCBSN !== "") {
            this.handerUploadConfig.code = "B";
            this.handerUploadConfig.TraySN = this.assembling.BTraySN;
            this.handerUploadConfig.PCBSN = this.assembling.BPCBSN;
            this.handerUploadConfig.operatorType = "pcb_check";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
    };
    //tray上传
    KeycapDetailComponent.prototype.trayUpload = function () {
        if (this.status == "工作中") {
            return;
        }
        if (this.assembling.ATraySN === "" && this.assembling.BTraySN === "") {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "SN不能为空",
            });
            return;
        }
        if (this.assembling.ATraySN !== undefined && this.assembling.ATraySN !== ""
            && this.assembling.APCBSN !== undefined && this.assembling.APCBSN !== "") {
            this.handerUploadConfig.code = "A";
            this.handerUploadConfig.TraySN = this.assembling.ATraySN;
            this.handerUploadConfig.PCBSN = this.assembling.APCBSN;
            this.handerUploadConfig.operatorType = "tray_upload";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
        if (this.assembling.BTraySN !== undefined && this.assembling.BTraySN !== ""
            && this.assembling.BPCBSN !== undefined && this.assembling.BPCBSN !== "") {
            this.handerUploadConfig.code = "B";
            this.handerUploadConfig.TraySN = this.assembling.BTraySN;
            this.handerUploadConfig.PCBSN = this.assembling.BPCBSN;
            this.handerUploadConfig.operatorType = "tray_upload";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
    };
    KeycapDetailComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    //PCB上传
    KeycapDetailComponent.prototype.pcbUpload = function () {
        if (this.status == "工作中") {
            return;
        }
        if (this.assembling.APCBSN === "" && this.assembling.BPCBSN === "") {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "SN不能为空",
            });
            return;
        }
        if (this.assembling.APCBSN !== undefined && this.assembling.APCBSN !== "") {
            this.handerUploadConfig.code = "A";
            this.handerUploadConfig.TraySN = this.assembling.ATraySN;
            this.handerUploadConfig.PCBSN = this.assembling.APCBSN;
            this.handerUploadConfig.operatorType = "pcb_upload";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
        if (this.assembling.BPCBSN !== undefined && this.assembling.BPCBSN !== "") {
            this.handerUploadConfig.code = "B";
            this.handerUploadConfig.TraySN = this.assembling.BTraySN;
            this.handerUploadConfig.PCBSN = this.assembling.BPCBSN;
            this.handerUploadConfig.operatorType = "pcb_upload";
            this.ipcService.send("handerUpload", this.handerUploadConfig);
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", productdetail_1.productDetail)
    ], KeycapDetailComponent.prototype, "assembling", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], KeycapDetailComponent.prototype, "logs", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], KeycapDetailComponent.prototype, "status", void 0);
    KeycapDetailComponent = __decorate([
        core_1.Component({
            selector: 'keycapsdetail',
            templateUrl: "./webApp/component/keycapsDetails/keycapsdetail.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], KeycapDetailComponent);
    return KeycapDetailComponent;
}());
exports.KeycapDetailComponent = KeycapDetailComponent;
//# sourceMappingURL=keycapsdetail.js.map