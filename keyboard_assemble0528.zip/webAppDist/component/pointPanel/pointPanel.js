"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var PointPanel = /** @class */ (function () {
    function PointPanel(_ngZone) {
        this.pointshow = true;
        this.stationAshow = true;
        this.stationBshow = true;
        this.stationCshow = false;
        this.ispointPanelShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.showFlag = [false, false, true];
    }
    PointPanel.prototype.ngOnInit = function () {
    };
    PointPanel.prototype.onclose = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否关闭窗口",
            buttons: ["是", "否"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.ispointPanelShow.emit(true);
            }
        });
    };
    PointPanel.prototype.openStationA = function () {
        this.stationAshow = false;
        this.stationBshow = true;
        this.stationCshow = true;
        this.showFlag = [true, false, false];
    };
    PointPanel.prototype.openstationB = function () {
        this.stationBshow = false;
        this.stationAshow = true;
        this.stationCshow = true;
        this.showFlag = [false, true, false];
    };
    PointPanel.prototype.openstationC = function () {
        this.stationBshow = true;
        this.stationAshow = true;
        this.stationCshow = false;
        this.showFlag = [false, false, true];
    };
    PointPanel.prototype.getUserandOpstatus = function (opssttus, userrole) {
        this.machinestatus = opssttus;
        this.userinfo = userrole;
    };
    PointPanel.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], PointPanel.prototype, "ispointPanelShow", void 0);
    PointPanel = __decorate([
        core_1.Component({
            selector: 'point-panel',
            templateUrl: "./webApp/component/pointPanel/pointPanel.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone])
    ], PointPanel);
    return PointPanel;
}());
exports.PointPanel = PointPanel;
//# sourceMappingURL=pointPanel.js.map