"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var headerinfo_1 = require("../../common/bean/headerinfo");
var ipc_service_1 = require("../../common/service/ipc.service");
var PcbCountComponent = /** @class */ (function () {
    function PcbCountComponent(_ngZone, ipcService) {
        this.changeStatus = new core_1.EventEmitter();
        this.machineConnectStyle = ["noconnect", "noconnect", "noconnect", "noconnect"];
        this._ngZone = _ngZone;
        this.statusClass = "initstatus";
        this.ipcService = ipcService;
        this.isStart = false;
    }
    //改变状态显示
    PcbCountComponent.prototype.changestatus = function (data) {
        var _this = this;
        switch (data) {
            case 0:
                this.status = "未初始化"; //红
                this.statusClass = "initstatus";
                this.isStart = false;
                break;
            case 1:
                this.status = "未连接"; //红
                this.statusClass = "initstatus";
                this.isStart = false;
                break;
            case 2:
                this.status = "急停"; //红
                this.statusClass = "initstatus";
                this.isStart = false;
                break;
            case 3:
                this.status = "请复位"; //红
                this.statusClass = "initstatus";
                this.isStart = false;
                break;
            case 4:
                this.status = "复位中"; //绿
                this.isStart = true;
                this.statusClass = "workstatus";
                break;
            case 5:
                this.status = "停止中";
                this.statusClass = "workstatus";
                this.isStart = false;
                break;
            case 6:
                this.status = "就绪"; //蓝色
                this.statusClass = "finishstatus";
                if (this.isStart) {
                    this.headerinfo.Atraynumber = 0;
                    this.headerinfo.Btraynumber = 0;
                    this.headerinfo.BtrayStyle = false;
                    this.headerinfo.AtrayStyle = false;
                    this.ipcService.send("Warehousezero", {
                        "code": "A"
                    });
                    this.ipcService.send("resetTrayData", {
                        "code": "A"
                    });
                    setTimeout(function () {
                        _this.ipcService.send("Warehousezero", {
                            "code": "B"
                        });
                        _this.ipcService.send("resetTrayData", {
                            "code": "B"
                        });
                    }, 1000);
                }
                this.isStart = false;
                break;
            case 7:
                this.status = "暂停"; //黄
                this.statusClass = "stopstatus";
                this.isStart = false;
                break;
            case 8:
                this.status = "工作中"; //绿
                this.statusClass = "workstatus";
                this.isStart = false;
                break;
        }
        this.changeStatus.emit(this.status);
    };
    //重置计数
    PcbCountComponent.prototype.resetData = function () {
        if (this.status == "工作中") {
            return;
        }
        this.ipcService.send("resetTrayData", { code: "totalPCBnumber" }); //清除成品数量
        // this.headerinfo.Acycletime = 0;
        // this.headerinfo.Atraynumber = 0;
        // this.headerinfo.Bcycletime = 0;
        // this.headerinfo.Btraynumber = 0;
        // this.headerinfo.CT = 0;
        this.headerinfo.finishKeyBoard = 0;
        //this.headerinfo.headdetail = [];
        this.headerinfo.totalPCBnumber = 0;
    };
    //四个通讯显示  小于等于0-未初始化 1-错误 2-ok，中间件只发后三个的通讯，UI通讯前端监听
    PcbCountComponent.prototype.readMachineConnect = function (data) {
        if (data.CCDCnt <= 0) {
            this.machineConnectStyle[1] = "noinit";
        }
        else if (data.CCDCnt === 1) {
            this.machineConnectStyle[1] = "err";
        }
        else {
            this.machineConnectStyle[1] = "";
        }
        if (data.pcbScannerCnt <= 0) {
            this.machineConnectStyle[2] = "noinit";
        }
        else if (data.pcbScannerCnt === 1) {
            this.machineConnectStyle[2] = "err";
        }
        else {
            this.machineConnectStyle[2] = "";
        }
        if (data.trayScannerCnt <= 0) {
            this.machineConnectStyle[3] = "noinit";
        }
        else if (data.trayScannerCnt === 1) {
            this.machineConnectStyle[3] = "err";
        }
        else {
            this.machineConnectStyle[3] = "";
        }
        if (data.SFCconnect <= 0) {
            this.machineConnectStyle[4] = "noinit";
        }
        else if (data.trayScannerCnt === 1) {
            this.machineConnectStyle[4] = "err";
        }
        else {
            this.machineConnectStyle[4] = "";
        }
    };
    //与中间件连接上
    PcbCountComponent.prototype.openUIConnect = function () {
        this.machineConnectStyle[0] = "";
    };
    //与中间件断开连接
    PcbCountComponent.prototype.closeUIConnect = function () {
        for (var i = 0; i < this.machineConnectStyle.length; i++) {
            this.machineConnectStyle[i] = "noconnect";
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], PcbCountComponent.prototype, "status", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], PcbCountComponent.prototype, "headerinfo", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], PcbCountComponent.prototype, "changeStatus", void 0);
    PcbCountComponent = __decorate([
        core_1.Component({
            selector: 'pcbcount',
            templateUrl: "./webApp/component/pcbcount/pcbcount.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], PcbCountComponent);
    return PcbCountComponent;
}());
exports.PcbCountComponent = PcbCountComponent;
//# sourceMappingURL=pcbcount.js.map