"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var Pointdata_1 = require("../../common/bean/Pointdata");
var ipc_service_1 = require("../../common/service/ipc.service");
var StationB = /** @class */ (function () {
    function StationB(_ngZone, ipcService) {
        this.isShow = true;
        this.ioListB = Pointdata_1.IOListB;
        this.ioListold = Pointdata_1.IOListB1;
        this.ioisShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
    }
    StationB.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("getPoint", function (data) {
            _this._ngZone.run(function () {
                _this.getPointfun(data.data.station, data.data.xPoint, data.data.yPoint, data.data.zPoint, data.data.pointname);
            });
        });
    };
    StationB.prototype.onclose = function () {
        this.ioisShow.emit(this.isShow);
    };
    StationB.prototype.getPointfun = function (station, xPoint, yPoint, zPoint, name) {
        for (var i = 0; i < this.ioListB.length; i++) {
            if (this.ioListB[i].index === station) {
                var pointinfo = this.ioListB[i].pointinfo;
                var pointinfoold = this.ioListold[i].pointinfo;
                //let message = Object.assign([],pointinfo );
                for (var j = 0; j < pointinfo.length; j++) {
                    if (pointinfo[j].name == name) {
                        pointinfo[j].xpoint = xPoint;
                        pointinfo[j].ypoint = yPoint;
                        pointinfo[j].zpoint = zPoint;
                        pointinfoold[j].xpoint = xPoint;
                        pointinfoold[j].ypoint = yPoint;
                        pointinfoold[j].zpoint = zPoint;
                    }
                }
            }
        }
    };
    StationB.prototype.savePoint = function () {
        console.info("sfsdf");
        for (var i = 0; i < this.ioListB.length; i++) {
            for (var j = 0; j < this.ioListB[i].pointinfo.length; j++) {
                if (this.ioListB[i].pointinfo[j].xpoint !== this.ioListold[i].pointinfo[j].xpoint) {
                    var stationid = this.ioListB[i].index;
                    var stationname = this.ioListB[i].name;
                    var name_1 = this.ioListB[i].pointinfo[j].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_1, "xPoint": this.ioListB[i].pointinfo[j].xpoint, "yPoint": this.ioListB[i].pointinfo[j].ypoint, "zPoint": this.ioListB[i].pointinfo[j].zpoint, "prexpoint": this.ioListold[i].pointinfo[j].xpoint, "totalpoint": this.ioListB[i].pointinfo[j].total, "change": "x" });
                    this.ioListold[i].pointinfo[j].xpoint = this.ioListB[i].pointinfo[j].xpoint;
                }
                if (this.ioListB[i].pointinfo[j].ypoint !== this.ioListold[i].pointinfo[j].ypoint) {
                    var stationid = this.ioListB[i].index;
                    var name_2 = this.ioListB[i].pointinfo[j].name;
                    var stationname = this.ioListB[i].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_2, "xPoint": this.ioListB[i].pointinfo[j].xpoint, "yPoint": this.ioListB[i].pointinfo[j].ypoint, "zPoint": this.ioListB[i].pointinfo[j].zpoint, "prexpoint": this.ioListold[i].pointinfo[j].ypoint, "totalpoint": this.ioListB[i].pointinfo[j].total, "change": "y" });
                    this.ioListold[i].pointinfo[j].ypoint = this.ioListB[i].pointinfo[j].ypoint;
                }
                if (this.ioListB[i].pointinfo[j].zpoint !== this.ioListold[i].pointinfo[j].zpoint) {
                    var stationid = this.ioListB[i].index;
                    var name_3 = this.ioListB[i].pointinfo[j].name;
                    var stationname = this.ioListB[i].name;
                    this.ipcService.send("setPoint", { "stationname": stationname, "station": stationid, "pointname": name_3, "xPoint": this.ioListB[i].pointinfo[j].xpoint, "yPoint": this.ioListB[i].pointinfo[j].ypoint, "zPoint": this.ioListB[i].pointinfo[j].zpoint, "prexpoint": this.ioListold[i].pointinfo[j].zpoint, "totalpoint": this.ioListB[i].pointinfo[j].total, "change": "z" });
                    this.ioListold[i].pointinfo[j].zpoint = this.ioListB[i].pointinfo[j].zpoint;
                }
            }
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], StationB.prototype, "machinestatus", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], StationB.prototype, "userrole", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], StationB.prototype, "ioisShow", void 0);
    StationB = __decorate([
        core_1.Component({
            selector: 'station-b',
            templateUrl: "./webApp/component/stationB/stationB.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], StationB);
    return StationB;
}());
exports.StationB = StationB;
//# sourceMappingURL=stationB.js.map