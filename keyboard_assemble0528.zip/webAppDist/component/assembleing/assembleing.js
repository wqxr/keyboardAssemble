"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var assembling_1 = require("../../common/bean/assembling");
var AssembleinfoComponent = /** @class */ (function () {
    function AssembleinfoComponent(_ngZone) {
        this.stationItem = new StationItem();
        this.isodownstyle = "";
        this.isoupstyle = "";
        this.isoleftdownstyle = "";
        this.isoleftupstyle = "";
        this.lefttotal = 0;
        this.righttotal = 0;
        this.changeclass = "";
        this.assembclass = "";
        this.assemblingClass = new AssemblingClass();
        this.ansiupstyle = "";
        this.ansidownstyle = "";
        this.ansileftupstyle = "";
        this.ansileftdownstyle = "";
        this.jisupstyle = "";
        this.jisdownstyle = "";
        this.jisleftupstyle = "";
        this.jisleftdownstyle = "";
        this.nowclass = "";
        this.backclass = "";
        this.photoclass = "";
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
    }
    AssembleinfoComponent.prototype.workassemb = function (data) {
        var _this = this;
        if (data.target == "left") {
            console.log("keycaps:" + this.assembling.keycaps);
            if (data.type == "ANSI") {
                this.stationItem.isANSIleft = true;
                this.stationItem.isISOleft = false;
                this.stationItem.isJISleft = false;
                if (data.status == 0) {
                    this.lefttotal += 1;
                    this.ansileftdownstyle = "k-l-step2";
                    this.ansileftupstyle = "t-l-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.ansileftupstyle = "k-step1";
                    this.ansileftupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.leftchangeclass = true;
                    this.assemblingClass.leftassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.leftshowclass = true;
                        _this.assemblingClass.leftchangeclass = false;
                    });
                }
                else if (data.status == 3) {
                    this.ansileftdownstyle = "k-l-step1";
                    this.ansileftupstyle = "t-l-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    this.assemblingClass.leftup1class = true;
                    this.photoclass = "";
                }
            }
            else if (data.type == "ISO") {
                this.stationItem.isISOleft = true;
                this.stationItem.isANSIleft = false;
                this.stationItem.isJISleft = false;
                if (data.status == 0) {
                    this.lefttotal += 1;
                    this.isoleftdownstyle = "k-l-step2";
                    this.isoleftupstyle = "t-l-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.isoleftdownstyle = "k-step1";
                    this.isoleftupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.leftchangeclass = true;
                    this.assemblingClass.leftassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.leftshowclass = true;
                        _this.assemblingClass.leftchangeclass = false;
                    });
                }
                else if (data.status == 3) {
                    this.isoleftdownstyle = "k-l-step1";
                    this.isoleftupstyle = "t-l-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    this.assemblingClass.leftup1class = true;
                    this.photoclass = "";
                }
            }
            else if (data.type = "JIS") {
                this.stationItem.isJISleft = true;
                this.stationItem.isANSIleft = false;
                this.stationItem.isISOleft = false;
                if (data.status == 0) {
                    this.lefttotal += 1;
                    this.jisdownstyle = "k-l-step2";
                    this.jisupstyle = "t-l-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.jisleftdownstyle = "k-step1";
                    this.jisleftupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.leftchangeclass = true;
                    this.assemblingClass.leftassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.leftshowclass = true;
                        _this.assemblingClass.leftchangeclass = false;
                    });
                }
                else if (data.status == 3) {
                    this.jisleftdownstyle = "k-l-step1";
                    this.jisleftupstyle = "t-l-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    this.assemblingClass.leftup1class = true;
                    this.photoclass = "";
                }
            }
        }
        else if (data.target == "right") {
            if (data.type == "ANSI") {
                this.stationItem.isANSIright = true;
                this.stationItem.isISOright = false;
                this.stationItem.isJISright = false;
                if (data.status == 0) {
                    this.righttotal += 1;
                    this.ansidownstyle = "k-r-step2";
                    this.ansiupstyle = "t-r-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.ansidownstyle = "k-step1";
                    this.ansiupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.rightchangeclass = true;
                    this.assemblingClass.rightassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.rightshowclass = true;
                        _this.assemblingClass.rightchangeclass = false;
                    });
                }
                else if (data.status == 3) {
                    this.ansidownstyle = "k-r-step1";
                    this.ansiupstyle = "t-r-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    this.assemblingClass.rightup1class = true;
                    this.photoclass = "";
                }
            }
            else if (data.type == "ISO") {
                this.stationItem.isISOright = true;
                this.stationItem.isANSIright = false;
                this.stationItem.isJISright = false;
                if (data.status == 0) {
                    this.righttotal += 1;
                    this.isodownstyle = "k-r-step2";
                    this.isoupstyle = "t-r-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.isodownstyle = "k-step1";
                    this.isoupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.rightchangeclass = true;
                    this.assemblingClass.rightassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.rightshowclass = true;
                        _this.assemblingClass.rightchangeclass = false;
                    }, 1000);
                }
                else if (data.status == 3) {
                    this.isodownstyle = "k-r-step1";
                    this.isoupstyle = "t-r-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    this.assemblingClass.rightup1class = true;
                    this.photoclass = "";
                }
            }
            else if (data.type == "JIS") {
                this.stationItem.isJISright = true;
                this.stationItem.isANSIright = false;
                this.stationItem.isISOright = false;
                if (data.status == 0) {
                    this.righttotal += 1;
                    this.jisdownstyle = "k-r-step2";
                    this.jisupstyle = "t-r-step2";
                    this.photoclass = "";
                }
                else if (data.status == 1) {
                    this.jisdownstyle = "k-step1";
                    this.jisupstyle = "";
                    this.photoclass = "sca-ani";
                }
                else if (data.status == 2) {
                    this.assemblingClass.rightchangeclass = true;
                    this.assemblingClass.rightassembclass = true;
                    this.photoclass = "";
                    setTimeout(function () {
                        _this.assemblingClass.rightshowclass = true;
                        _this.assemblingClass.rightchangeclass = false;
                    });
                }
                else if (data.status == 3) {
                    this.jisdownstyle = "k-r-step1";
                    this.jisupstyle = "t-r-step1";
                    this.photoclass = "";
                }
                else if (data.status == 4) {
                    //this.assembclass="up1";
                    this.assemblingClass.rightup1class = true;
                    this.photoclass = "";
                }
            }
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", assembling_1.Assembling)
    ], AssembleinfoComponent.prototype, "assembling", void 0);
    AssembleinfoComponent = __decorate([
        core_1.Component({
            selector: 'assemble_info',
            templateUrl: "./webApp/component/assembleing/assembleing.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone])
    ], AssembleinfoComponent);
    return AssembleinfoComponent;
}());
exports.AssembleinfoComponent = AssembleinfoComponent;
var StationItem = /** @class */ (function () {
    function StationItem() {
        this.isANSIleft = false;
        this.isISOleft = false;
        this.isJISleft = false;
        this.isANSIright = false;
        this.isISOright = false;
        this.isJISright = false;
    }
    return StationItem;
}());
var AssemblingClass = /** @class */ (function () {
    function AssemblingClass() {
        this.leftchangeclass = false;
        this.leftassembclass = false;
        this.rightchangeclass = false;
        this.rightassembclass = false;
        this.leftshowclass = false;
        this.rightshowclass = false;
        this.leftup1class = false;
        this.rightup1class = false;
    }
    return AssemblingClass;
}());
//# sourceMappingURL=assembleing.js.map