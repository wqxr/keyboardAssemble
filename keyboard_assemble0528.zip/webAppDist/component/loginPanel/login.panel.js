"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var LoginlPanel = /** @class */ (function () {
    function LoginlPanel(ipcService, _ngZone) {
        this.loginResult = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.display = "block";
        this.username = "";
        this.password = "";
        this.ipcService = ipcService;
        //this.role ="";
        this.adminrole = "";
        this.oprole = "";
    }
    LoginlPanel.prototype.ngOnInit = function () {
        var _this = this;
        this.ipcService.on("loginresult", function (response) {
            _this._ngZone.run(function () {
                if (response.data.code !== 1) {
                    _this.errorMsg = "您输入的密码错误";
                    return;
                }
                if (response.data.code === 1) {
                    _this.loginResult.emit({
                        isLogin: true, role: _this.oprole,
                    });
                    _this.hiddenLoginPanel();
                }
            });
            //console.info("用户：" + response.data.resultCode);
        });
    };
    LoginlPanel.prototype.userlogin = function () {
        if (false === this.check()) {
            return;
        }
        if (!isNaN(this.role)) {
            this.oprole = "op";
        }
        else {
            this.oprole = "admin";
        }
        //  if(this.role==="admin"){
        //    this.adminrole="a";
        //  }
        //  if(this.role==="op"){
        //    this.adminrole="1";
        //  }
        this.ipcService.send("login", { "username": this.role, "psw": this.password });
        //  this.display = "none";
        //   this.loginResult.emit({
        //     isLogin: true, role: this.role,
        //   });
    };
    LoginlPanel.prototype.loginin = function (event) {
        if (event.keyCode === 13) {
            this.userlogin();
        }
    };
    // showLoginPanel() {
    //   this.display = "flex";
    //   this.password="";
    //   return new Promise((resolve, reject) => {
    //     this.resolveFunc = resolve;
    //     this.rejectFunc = reject;
    //   });
    // }
    LoginlPanel.prototype.hiddenLoginPanel = function () {
        this.display = "none";
    };
    LoginlPanel.prototype.showLoginPanel = function () {
        this.display = "block";
    };
    LoginlPanel.prototype.check = function () {
        this.errorMsg = "";
        // if(!this.role){
        //   this.errorMsg="请输入用户名"
        // }if(!this.role){
        //   this.errorMsg="请输入用户名"
        // }
        if (!this.password || !this.role) {
            this.errorMsg = "请输入密码或者用户名";
            return false;
        }
        return true;
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], LoginlPanel.prototype, "loginStatus", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], LoginlPanel.prototype, "onlogin", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], LoginlPanel.prototype, "loginResult", void 0);
    LoginlPanel = __decorate([
        core_1.Component({
            selector: 'login-panel',
            templateUrl: "./webApp/component/loginPanel/loginPanel.html",
        }),
        __metadata("design:paramtypes", [ipc_service_1.IPCService, core_1.NgZone])
    ], LoginlPanel);
    return LoginlPanel;
}());
exports.LoginlPanel = LoginlPanel;
//# sourceMappingURL=login.panel.js.map