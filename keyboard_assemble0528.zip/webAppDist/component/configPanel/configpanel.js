"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var _ = require("lodash");
var io_service_1 = require("../../service/io.service");
var IOData_1 = require("../../common/bean/IOData");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var Configpanel = /** @class */ (function () {
    function Configpanel(_ngZone, ipcServive, IOService) {
        this.isShow = true;
        this.iOList = IOData_1.IOList;
        this.ioisShow = new core_1.EventEmitter();
        this.iscongigshow = true;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcServive;
        this.IOService = IOService;
        console.log(_.isString(this.title));
    }
    Configpanel.prototype.switchTab = function (tabIndex) {
        this.iOList.forEach(function (item) {
            item.hidden = true;
        });
        this.iOList[tabIndex].hidden = false;
    };
    Configpanel.prototype.ngOnInit = function () {
        var _this = this;
        this.iOList[0].hidden = false;
        this.ipcService.on("operateIO_result", function (message) {
            _this._ngZone.run(function () {
                _this.IOService.parseIntIo(message.data.cardID, message.data.value, message.data.IOtype);
                //this.iOService.updateCardIo(ioVal);
            });
        });
    };
    Configpanel.prototype.operateIo = function (io) {
        // let val = io.value;
        io.value = io.value === 0 ? 1 : 0;
        // let value=val;
        var name = io.name;
        this.ipcService.send("operateIo", {
            'cardId': io.cardId, 'index': io.index, 'value': io.value, 'name': name
        });
        // if(io.value===1){
        //     io.value=0;
        // }else{
        //     io.value=1;
        // }
    };
    Configpanel.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    Configpanel.prototype.onclose = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否关闭窗口",
            buttons: ["是", "否"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.ioisShow.emit(true);
            }
        });
    };
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], Configpanel.prototype, "ioisShow", void 0);
    Configpanel = __decorate([
        core_1.Component({
            selector: 'config-panel',
            templateUrl: "./webApp/component/configPanel/configpanel.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService, io_service_1.IOService])
    ], Configpanel);
    return Configpanel;
}());
exports.Configpanel = Configpanel;
//# sourceMappingURL=configpanel.js.map