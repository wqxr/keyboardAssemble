"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var _ = require("lodash");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var AsideComponent = /** @class */ (function () {
    function AsideComponent(_ngZone, ipcService) {
        this.configisShow = new core_1.EventEmitter();
        this.configinfo = new core_1.EventEmitter();
        this.iscongigshow = true;
        this.SAVE_PATH = "D:/ShopFlow/assemble.ini";
        this.startclass = false;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        console.log(_.isString(this.title));
        this.config = {
            IP: "",
            MAC_ADDR: "",
            MachineNo: "",
            StationNo: "",
            LineNo: "",
            StationVer: "",
            AOutTrayCount: 30,
            BOutTrayCount: 30,
            machineType: "",
            CTtime: "",
        };
        this.ipcService = ipcService;
        // this.config = new Config();
    }
    AsideComponent.prototype.ngOnInit = function () {
        this.configinfo.emit([this.config.IP, this.config.MAC_ADDR, this.config.StationNo,
            this.config.MachineNo, this.config.LineNo, this.config.StationVer, this.config.AOutTrayCount, this.config.BOutTrayCount, this.config.machineType, this.config.CTtime]);
        //this.ipcService.send("machineConfig",this.config);
        // this.ipcService.on("isOk", (data) => {//上料信号
        //   this._ngZone.run(() => {
        //     if(data.data.code===1){
        //       this.showMessageBox(browserWindow, {
        //         type: "warning",
        //         message: "保存成功",
        //       });
        //       return;
        //     }
        //   })
        // })
    };
    AsideComponent.prototype.saveConfig = function () {
        if (this.config.AOutTrayCount > 30 || this.config.BOutTrayCount > 30) {
            this.showMessageBox(browserWindow, {
                type: "warning",
                message: "预计出料个数不能超过30",
            });
            return;
        }
        this.ipcService.send("machineConfig", this.config);
        this.configinfo.emit([this.config.IP, this.config.MAC_ADDR, this.config.StationNo,
            this.config.MachineNo, this.config.LineNo, this.config.StationVer, this.config.AOutTrayCount, this.config.BOutTrayCount, this.config.machineType, this.config.CTtime]);
    };
    AsideComponent.prototype.readmachineconfig = function (data) {
        this.config = data;
    };
    AsideComponent.prototype.onclose = function () {
        var _this = this;
        this.showMessageBox(browserWindow, {
            type: "warning",
            message: "是否关闭窗口",
            buttons: ["是", "否"],
            defaultId: 0,
            cancelId: -1,
        }).then(function (btnIndex) {
            if (btnIndex === 0) {
                _this.configisShow.emit(true);
                _this.iscongigshow = !_this.iscongigshow;
            }
        });
    };
    AsideComponent.prototype.cancel = function () {
        this.configisShow.emit(this.iscongigshow);
        this.iscongigshow = !this.iscongigshow;
    };
    AsideComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configs", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], AsideComponent.prototype, "configinfo", void 0);
    AsideComponent = __decorate([
        core_1.Component({
            selector: 'io-panel',
            templateUrl: "./webApp/component/aside/aside.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], AsideComponent);
    return AsideComponent;
}());
exports.AsideComponent = AsideComponent;
//# sourceMappingURL=aside.js.map