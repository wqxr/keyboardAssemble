"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var headerinfo_1 = require("../../common/bean/headerinfo");
var ipc_service_1 = require("../../common/service/ipc.service");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var HeaderinfoComponent = /** @class */ (function () {
    function HeaderinfoComponent(_ngZone, ipcService) {
        var _this = this;
        this.isrepaire = false;
        this.ismatain = false;
        this.isShow = false;
        this.iscongigshow = false;
        this.configshowtext = "配置面板";
        this.ioisshowText = "IO面板";
        this.startclass = false;
        this.emergencyclass = false;
        this.resetclass = false;
        this.suspendclass = false;
        this.stopClass = false;
        this.isUseShow = false;
        this.pointShow = false;
        this.fullScreenFlag = false; //全屏
        //io面板
        this.ioisShow = new core_1.EventEmitter();
        //配置
        this.configisShow = new core_1.EventEmitter();
        this.isUseShowfun = new core_1.EventEmitter();
        //点位
        this.ispointPanelShow = new core_1.EventEmitter();
        //登录
        this.isloginPanelShow = new core_1.EventEmitter();
        //修改密码
        this.ischangepwdPanelShow = new core_1.EventEmitter();
        this.outlogin = new core_1.EventEmitter();
        this._ngZone = _ngZone;
        this.ipcService = ipcService;
        this.styleclass = [false, false, false];
        this.opreatelist = [];
        this.isShowLoginOut = true;
        this.loginstatus = "退出登录";
        this.repairtime = "维修";
        this.protecttime = "保养";
        this.repairtotaltime = 0;
        this.mataintotaltime = 0;
        this.repairAlltime = 0;
        this.matainAlltime = 0;
        this.repairstartTime = 0;
        this.matainstarttime = 0;
        this.matainendtime = 0;
        this.machineTime = {
            "product": "",
            "cm": "WISTRON",
            "cm_line": "",
            "machine_number": "",
            "manufacturer": "FP",
            "time_local": "",
            "total_time": 3600,
            "scheduled_time": 3600,
            "unscheduled_downtime": 0,
            "scheduled_downtime": 0,
            "engineering_time": 0,
            "idle_time": 0,
            "production_time": 0,
            "unit_count": 0,
            "pass_count": 0,
            "pass_cycle_time": "",
            "fail_cycle_time": 0,
            "planned_cycle_time": "",
            "Date": "",
            "Hour": "",
        };
        this.clickclass = [false, false, false, false, false, false, false, false, false, false];
        // setInterval(()=>{
        //   this.getProductdata();
        // },1000);
        this.ipcService.on("machineTime", function (response) {
            _this._ngZone.run(function () {
                var now = new Date();
                if (_this.isrepaire === true) {
                    _this.repairAlltime = _this.repairtotaltime + (Date.now() - _this.repairstartTime) / 1000;
                }
                else if (_this.ismatain === true) {
                    _this.matainAlltime = _this.mataintotaltime + (Date.now() - _this.matainstarttime) / 1000;
                }
                // this.repairtotaltime= this.repairtotaltime+(Date.now()-this.repairstartTime)/1000;
                // this.mataintotaltime=this.mataintotaltime+(Date.now()-this.matainstarttime)/1000;
                _this.machineTime = response.data;
                _this.machineTime.cm = "WISTRON";
                _this.machineTime.manufacturer = "FP";
                _this.machineTime.product = _this.configinfos.macineType; //机种
                _this.machineTime.cm_line = _this.configinfos.LineNo; //线别
                _this.machineTime.machine_number = "WIZS_" + _this.configinfos.LineNo + "_01_HA1";
                _this.machineTime.planned_cycle_time = _this.configinfos.CTtime;
                _this.machineTime.scheduled_downtime = _this.repairAlltime;
                _this.machineTime.engineering_time = _this.matainAlltime;
                _this.machineTime.total_time = response.data.total_time;
                _this.machineTime.scheduled_time = response.data.total_time;
                _this.machineTime.Date = "" + now.getFullYear() + "/" + (now.getMonth() + 1) + "/" + now.getDate();
                _this.machineTime.time_local = "" + _this.machineTime.Date + now.getHours() + ":00:00";
                _this.machineTime.Hour = "" + now.getHours();
                _this.machineTime.production_time = response.data.production_time;
                _this.machineTime.unscheduled_downtime = response.data.unscheduled_downtime;
                _this.machineTime.idle_time = _this.machineTime.total_time - _this.machineTime.production_time - _this.machineTime.engineering_time - _this.machineTime.scheduled_downtime;
                _this.machineTime.unit_count = response.data.unit_count;
                _this.machineTime.pass_count = _this.machineTime.unit_count;
                if (_this.machineTime.unit_count === 0) {
                    _this.machineTime.pass_cycle_time = "0";
                }
                _this.machineTime.pass_cycle_time = (_this.machineTime.production_time / _this.machineTime.unit_count).toFixed(3);
                _this.machineTime.fail_cycle_time = 0;
                _this.ipcService.send("machineTimeconfig", _this.machineTime);
                //console.info(this.machineTime);
                _this.saveProductdata();
            });
        });
    }
    //启动 就绪状态才能点
    HeaderinfoComponent.prototype.startUp = function () {
        if (this.status !== "就绪") {
            return;
        }
        this.clickclass = [true, false, false, false, false, false, false, false, false, false];
        if (this.configinfos.IP.indexOf('.') === -1 || this.configinfos.LineNo.indexOf("-") === -1 || this.configinfos.MAC_ADDR.indexOf("-") === -1 || this.configinfos.StationNo.indexOf("-") === -1) {
            this.warn.loginfo = '配置文件配置不合理';
            this.warn.time = Date.now();
            this.warn.style = 'red';
            // this.configisShow.emit(this.iscongigshow);
            return;
        }
        else {
            this.warn.loginfo = "";
        }
        this.startclass = true;
        this.emergencyclass = false;
        this.resetclass = false;
        this.suspendclass = false;
        this.stopClass = false;
        this.ipcService.send("operate", {
            "code": 1
        });
        this.ipcService.send("trayCount", {
            "layers_a": this.headerinfo.Atraynumber,
            "layers_b": this.headerinfo.Btraynumber
        }); //清除A料仓数据
    };
    HeaderinfoComponent.prototype.repair = function () {
        if (this.protecttime === '保养中') {
            return;
        }
        this.isrepaire = true;
        this.ismatain = false;
        if (this.repairtime === "维修") {
            this.repairtime = "维修中";
            this.repairstartTime = Date.now();
        }
        else {
            this.repairtime = "维修";
            this.repairtotaltime = (Date.now() - this.repairstartTime) / 1000;
            this.repairAlltime += this.repairtotaltime;
        }
    };
    HeaderinfoComponent.prototype.matain = function () {
        if (this.repairtime === "维修中") {
            return;
        }
        this.ismatain = true;
        this.isrepaire = false;
        if (this.protecttime === "保养") {
            this.protecttime = "保养中";
            this.matainstarttime = Date.now();
        }
        else {
            this.protecttime = "保养";
            this.mataintotaltime = (Date.now() - this.repairstartTime) / 1000;
            this.matainAlltime += this.mataintotaltime;
        }
    };
    HeaderinfoComponent.prototype.saveProductdata = function () {
        this.repairstartTime = Date.now();
        this.matainstarttime = Date.now();
        this.repairAlltime = 0;
        this.matainAlltime = 0;
    };
    HeaderinfoComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    //急停  
    HeaderinfoComponent.prototype.emergencyStop = function () {
        this.startclass = false;
        this.resetclass = false;
        this.suspendclass = false;
        this.emergencyclass = true;
        this.stopClass = false;
        this.ipcService.send("operate", {
            "code": 0
        });
    };
    //复位 除了未连接都可以
    HeaderinfoComponent.prototype.reset = function () {
        if (this.status === "未连接") {
            return;
        }
        this.clickclass = [false, true, false, false, false, false, false, false, false, false];
        this.startclass = false;
        this.suspendclass = false;
        this.emergencyclass = false;
        this.resetclass = true;
        this.stopClass = false;
        this.ipcService.send("operate", {
            "code": 3
        });
    };
    //暂停  必须是工作中或者复位中
    HeaderinfoComponent.prototype.suspend = function () {
        this.clickclass = [false, false, true, false, false, false, false, false, false, false];
        if (this.status === "工作中" || this.status === "复位中" || this.status === "暂停") {
            this.opreatelist.push(0);
            if (this.opreatelist.length % 2 == 0) {
                if (this.status === "工作中") {
                    this.startclass = true;
                    this.emergencyclass = false;
                    this.resetclass = false;
                    this.suspendclass = false;
                    this.stopClass = false;
                }
                else {
                    this.startclass = false;
                    this.emergencyclass = false;
                    this.resetclass = true;
                    this.suspendclass = false;
                    this.stopClass = false;
                }
                this.ipcService.send("operate", {
                    "code": 2
                });
            }
            else {
                this.startclass = false;
                this.emergencyclass = false;
                this.resetclass = false;
                this.suspendclass = true;
                this.stopClass = false;
                this.ipcService.send("operate", {
                    "code": 2
                });
            }
        }
    };
    //停止     必须是工作中或者复位中
    HeaderinfoComponent.prototype.stop = function () {
        if (this.status === "工作中" || this.status === "复位中") {
            this.clickclass = [false, false, false, true, false, false, false, false, false, false];
            this.startclass = false;
            this.emergencyclass = false;
            this.resetclass = false;
            this.suspendclass = false;
            this.stopClass = true;
            this.ipcService.send("operate", {
                "code": 4
            });
        }
    };
    HeaderinfoComponent.prototype.showIo = function () {
        if (this.userinformation.role == "操作员") {
            return;
        }
        this.clickclass = [false, false, false, false, true, false, false, false, false, false];
        this.ioisShow.emit(false);
        // this.isShow=!this.isShow;
    };
    HeaderinfoComponent.prototype.showConfig = function () {
        if (this.userinformation.role == "操作员") {
            return;
        }
        this.clickclass = [false, false, false, false, false, false, true, false, false, false];
        this.configisShow.emit(false);
        //this.iscongigshow=!this.iscongigshow;
    };
    HeaderinfoComponent.prototype.openLogPanel = function () {
        this.clickclass = [false, false, false, false, false, false, false, true, false, false];
        this.isUseShow = true;
        this.isUseShowfun.emit(false);
    };
    HeaderinfoComponent.prototype.loginIn = function () {
        // this.isloginPanelShow.emit(false);
        // this.styleclass[0] = false;
        // this.styleclass[1] = false;
        // if (this.styleclass[2] === true) {
        //   this.styleclass[2] = false;
        // } else {
        //   this.styleclass[2] = true;
        // }
        this.isShowLoginOut = !this.isShowLoginOut;
    };
    HeaderinfoComponent.prototype.login = function () {
        this.clickclass = [false, false, false, false, false, false, false, false, false, true];
        if (this.userinformation.isLogin === false) {
            this.loginstatus = "登录";
            this.outlogin.emit(false);
            this.isShowLoginOut = !this.isShowLoginOut;
        }
        else {
            // if (this.machineStatus === 8 || this.machineStatus === 3) {
            //   return;
            // }
            this.loginstatus = "退出登录";
            this.ipcService.send("loginout", { "username": "", "psw": "" }); //0代表退出
            this.isloginPanelShow.emit(false);
        }
    };
    HeaderinfoComponent.prototype.changpwd = function () {
        this.outlogin.emit(true);
    };
    // logout() {
    //   this.isloginPanelShow.emit(false);
    // }
    HeaderinfoComponent.prototype.openpointPanel = function () {
        // if (this.userinformation.role == "操作员") {
        //   return;
        // }
        this.clickclass = [false, false, false, false, false, true, false, false, false, false];
        this.ispointPanelShow.emit(false);
    };
    HeaderinfoComponent.prototype.fullScreen = function () {
        this.clickclass = [false, false, false, false, false, false, false, false, true, false];
        this.fullScreenFlag = !this.fullScreenFlag;
        nodeRequire('electron').remote.getCurrentWindow().setFullScreen(this.fullScreenFlag);
        if (this.fullScreen) {
            document.body.style.overflow = "hidden";
        }
        else {
            document.body.style.overflow = "auto";
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", String)
    ], HeaderinfoComponent.prototype, "status", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", headerinfo_1.Headerinfo)
    ], HeaderinfoComponent.prototype, "headerinfo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "configinfos", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], HeaderinfoComponent.prototype, "logs", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "warn", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "userinformation", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ioisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "configisShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "isUseShowfun", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ispointPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "isloginPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "ischangepwdPanelShow", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", Object)
    ], HeaderinfoComponent.prototype, "outlogin", void 0);
    HeaderinfoComponent = __decorate([
        core_1.Component({
            selector: 'headinfo',
            templateUrl: "./webApp/component/headerinfo/headerinfo.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone, ipc_service_1.IPCService])
    ], HeaderinfoComponent);
    return HeaderinfoComponent;
}());
exports.HeaderinfoComponent = HeaderinfoComponent;
//# sourceMappingURL=headerinfo.js.map