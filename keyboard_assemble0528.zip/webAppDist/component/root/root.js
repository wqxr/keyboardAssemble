"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ipc_service_1 = require("../../common/service/ipc.service");
var countinfoService_1 = require("../../service/countinfoService");
var assemblingService_1 = require("../../service/assemblingService");
var assemblystatusService_1 = require("../../service/assemblystatusService");
var TrayinfoService_1 = require("../../service/TrayinfoService");
var productionRecordService_1 = require("../../service/productionRecordService");
var headerinfo_1 = require("../../common/bean/headerinfo");
var workmodel_1 = require("../../common/bean/workmodel");
var trayinfo_1 = require("../../common/bean/trayinfo");
var msgType_1 = require("../../common/bean/msgType");
var productdetail_1 = require("../../common/bean/productdetail");
var Assembling_1 = require("../../common/bean/Assembling");
var assembleing_1 = require("../assembleing/assembleing");
var keycapsdetail_1 = require("../keycapsDetails/keycapsdetail");
var headerinfo_2 = require("../headerinfo/headerinfo");
var aside_1 = require("../aside/aside");
var keycaps_1 = require("../keycaps/keycaps");
var logPanel_1 = require("../logPanel/logPanel");
var login_panel_1 = require("../loginPanel/login.panel");
var change_password_1 = require("../changePassword/change.password");
var pcbcount_1 = require("../pcbcount/pcbcount");
var pointPanel_1 = require("../pointPanel/pointPanel");
var dialog = nodeRequire('electron').remote.dialog;
var browserWindow = nodeRequire('electron').remote.getCurrentWindow();
var AppComponent = /** @class */ (function () {
    function AppComponent(_ngZone, ipcService, countInfoService, assemblingService, assemblystatusService, trayinfoService, productionRecordService) {
        this.isShow = true;
        this.configShow = true;
        this.isUseShow = false;
        this.logshow = true;
        this.pointshow = true;
        this.maskshow = true;
        this.outTrayCount = 0;
        this.configinfo = {
            IP: "",
            MAC_ADDR: "",
            StationNo: "",
            MachineNo: "",
            LineNo: "",
            StationVer: "",
            AOutTrayCount: 0,
            BOutTrayCount: 0,
            macineType: "",
            CTtime: "",
        };
        this.isAoutTray = false;
        this.isBoutTray = false;
        this._ngZone = _ngZone;
        this.title = 'IAStudio';
        this.ipcService = ipcService;
        this.countInfoService = countInfoService;
        this.assemblingService = assemblingService;
        this.assemblystatusService = assemblystatusService;
        this.trayinfoService = trayinfoService;
        this.productionRecordService = productionRecordService;
        this.logs = [];
        this.ctnumber = true;
        this.starttime = 0;
        this.closewindow = true;
        this.loginStatus = {
            isLogin: false,
            role: "登录",
        };
        this.status = "请复位";
        this.warn = { time: 0, loginfo: "", style: "" };
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.headerinfo = new headerinfo_1.Headerinfo();
        this.workmodel = new workmodel_1.workModel();
        this.trayinfo = new trayinfo_1.Trayinfo();
        this.assembling = new Assembling_1.Assembling();
        this.productdetail = new productdetail_1.productDetail();
        this.headerinfo.Atraynumber = 0;
        this.headerinfo.Btraynumber = 0;
        this.headerinfo.totalPCBnumber = 0;
        var self = this;
        this.ipcService.on("countInfo", function (data) {
            _this._ngZone.run(function () {
                console.log("接受到的数据:" + data.data);
            });
        });
        this.ipcService.on("workingDetail", function (data) {
            _this._ngZone.run(function () {
                _this.assemblingService.updateheadInfo(_this.assembling, data.data, 1);
                _this.assemblingService.updateheadInfo(_this.assembling, data.data, 2);
                console.log("接受到的数据:" + data.data);
            });
        });
        this.ipcService.on("assemblyStatus", function (data) {
            _this._ngZone.run(function () {
                console.log("接受到的数据:" + data);
                _this.assembleing.workassemb(data.data[0]);
            });
        });
        this.ipcService.on("trayInfo", function (data) {
            _this._ngZone.run(function () {
                _this.trayinfoService.updatetrayInfo(_this.trayinfo, data.data);
            });
        });
        this.ipcService.on("emptyTray", function (data) {
            _this._ngZone.run(function () {
            });
        });
        this.ipcService.on("productionRecord", function (data) {
            _this._ngZone.run(function () {
                _this.productionRecordService.updateheadInfo(_this.productdetail, data);
            });
        });
        this.ipcService.on("warn", function (data) {
            _this._ngZone.run(function () {
                _this.logs.unshift({
                    time: Date.now(), loginfo: data.data.msg, style: "red"
                });
                var errorData = _this.logs.find(function (item) {
                    return item.style === "red";
                });
                _this.warn = Object.assign({}, errorData);
                _this.warn.loginfo = _this.warn.loginfo.split(",")[2];
            });
        });
        this.ipcService.on("log", function (data) {
            _this._ngZone.run(function () {
                _this.logs.unshift({
                    time: Date.now(), loginfo: data.data.msg, style: ""
                });
            });
        });
        this.ipcService.on("MachineConnect", function (data) {
            _this._ngZone.run(function () {
                _this.pcbCountComponent.readMachineConnect(data.data);
            });
        });
        this.ipcService.on("opsStatus", function (data) {
            _this._ngZone.run(function () {
                _this.pcbCountComponent.changestatus(data.data.status);
                _this.statusops = data.data.status;
                _this.pointpanel.getUserandOpstatus(_this.statusops, _this.loginStatus.role);
                //this.headerinfomation.changestatus(data.data.status);
            });
        });
        this.ipcService.on("inmaterial", function (data) {
            _this._ngZone.run(function () {
            });
        });
        this.ipcService.on("feederinfomation", function (data) {
            _this._ngZone.run(function () {
                _this.starttime = Date.now();
                if (data.data.code === "A") {
                    _this.AstartTime = Date.now();
                }
                else if (data.data.code === "B") {
                    _this.BstartTime = Date.now();
                }
                _this.assemblingService.assemblinginfo(_this.productdetail, data.data);
            });
        });
        this.ipcService.on("traynums", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === "A") {
                    _this.headerinfo.Atraynumber = data.data.nums;
                    var ARemainOutCount = _this.configinfo.AOutTrayCount - _this.headerinfo.Atraynumber;
                    if (ARemainOutCount < 3) {
                        _this.headerinfo.AtrayStyle = true;
                    }
                    if (_this.headerinfo.Atraynumber >= _this.configinfo.AOutTrayCount
                        && _this.configinfo.AOutTrayCount > 0) {
                        _this.warn.loginfo = "B仓库待出料";
                        _this.warn.style = "red";
                        // this.ipcService.send("Warehouseout", {
                        //   "code": "A"
                        // });
                    }
                }
                else if (data.data.code === "B") {
                    _this.headerinfo.Btraynumber = data.data.nums;
                    var BRemainOutCount = _this.configinfo.BOutTrayCount - _this.headerinfo.Btraynumber;
                    if (BRemainOutCount < 3) {
                        _this.headerinfo.BtrayStyle = true;
                    }
                    if (_this.headerinfo.Btraynumber >= _this.configinfo.BOutTrayCount
                        && _this.configinfo.BOutTrayCount > 0) {
                        _this.warn.loginfo = "B仓库待出料";
                        // this.warn.style="red";
                        // this.ipcService.send("Warehouseout", {
                        //   "code": "B"
                        // });
                    }
                }
            });
        });
        this.ipcService.on("page_readyResult", function (data) {
            _this._ngZone.run(function () {
                _this.headerinfo.Atraynumber = data.data.Atraynumber || 0;
                _this.headerinfo.Btraynumber = data.data.Btraynumber || 0;
                _this.headerinfo.totalPCBnumber = data.data.totalPCBnumber || 0;
                //this.keycapsComponent.readconfig(data.data);
                //this.asidecomponent.readmachineconfig(data.data);
            });
        });
        this.ipcService.on("machineconfig", function (data) {
            _this._ngZone.run(function () {
                // console.info(data.data);
                _this.configinfo.IP = data.data.IP;
                _this.configinfo.MAC_ADDR = data.data.MAC_ADDR;
                _this.configinfo.MachineNo = data.data.MachineNo;
                _this.configinfo.StationNo = data.data.StationNo;
                _this.configinfo.LineNo = data.data.LineNo;
                _this.configinfo.StationVer = data.data.StationVer;
                _this.configinfo.AOutTrayCount = data.data.AOutTrayCount;
                _this.configinfo.BOutTrayCount = data.data.BOutTrayCount;
                _this.configinfo.macineType = data.data.macineType;
                _this.configinfo.CTtime = data.data.CTtime;
                _this.headerinfo.AOutTrayCount = _this.configinfo.AOutTrayCount || 0;
                _this.headerinfo.BOutTrayCount = _this.configinfo.BOutTrayCount || 0;
                _this.asidecomponent.readmachineconfig(data.data);
                _this.checkConfig();
            });
        });
        //监听与中间件打开连接状态
        this.ipcService.on("connect", function (data) {
            _this._ngZone.run(function () {
                // setTimeout( (item)=>{
                // self.ipcService.send("trayCount", {
                //   "layers_a":  self.headerinfo.Atraynumber,
                //   "layers_b":  self.headerinfo.Btraynumber
                // })//清除A料仓数据
                // setTimeout(()=>{
                // this.ipcService.send("machineconfig",this.configinfo);
                // },500);
                // this.ipcService.send("machineConfig", this.configinfo);
                _this.pcbCountComponent.openUIConnect();
                //this.pcbCountComponent.openUIConnect();
                //},1000);
            });
        });
        //监听与中间件关闭状态
        this.ipcService.on("closeConnect", function (data) {
            _this._ngZone.run(function () {
                if (data.data.data === 0) {
                    _this.pcbCountComponent.closeUIConnect();
                    _this.statusops = 1;
                }
            });
        });
        // window.onbeforeunload = (event) => {
        //   //工作中或者复位中,不能关闭软件
        //   if (this.statusops === 8 || this.statusops === 4) {
        //     event.returnValue = false;
        //   }
        // }
        //不再有计数的接口
        // this.ipcService.on("traytotal", (data) => {//Tray盘计数
        //   this._ngZone.run(() => {
        //     if (data.data.code === "A") {
        //       this.headerinfo.Atraynumber = data.data.traytotal;
        //     } else {
        //       this.headerinfo.Btraynumber = data.data.traytotal;
        //     }
        //   })
        // })
        // this.ipcService.on("onloadProduct", (data) => {//Tray盘计数
        //   this._ngZone.run(() => {
        //     console.info("wqwqwqwq", data.data)
        //     this.assemblingService.onloadProduct(this.assembling, data.data);
        //   })
        // })
        this.ipcService.on("outmaterial", function (data) {
            _this._ngZone.run(function () {
                //将数据清空
                _this.productdetail.APCBSN = "";
                _this.productdetail.BPCBSN = "";
                _this.productdetail.ATraySN = "";
                _this.productdetail.codeStation = "";
                _this.productdetail.BTraySN = "";
                _this.productdetail.jobnumber = "";
                _this.productdetail.type = "";
                _this.productdetail.keynow = "";
                _this.assemblingService.productdetailinfo(_this.assembling, data.data);
                if (_this.ctnumber === true) {
                    _this.ctstarttime = Date.now();
                    _this.headerinfo.CT = (_this.ctstarttime - _this.starttime) / 1000;
                    _this.ctnumber = false;
                }
                else {
                    _this.headerinfo.CT = Date.now() - _this.ctstarttime;
                    _this.ctstarttime = Date.now();
                }
                if (data.data.code === "A") {
                    _this.AendTime = Date.now();
                    _this.headerinfo.Acycletime = (_this.AendTime - _this.AstartTime) / 1000;
                }
                else {
                    _this.BendTime = Date.now();
                    _this.headerinfo.Bcycletime = (_this.BendTime - _this.BstartTime) / 1000;
                }
                _this.headerinfo.totalPCBnumber = _this.headerinfo.totalPCBnumber + 1;
            });
        });
        this.ipcService.on("WarehouseoutOK", function (data) {
            _this._ngZone.run(function () {
                if (data.data.code === "A") {
                    _this.isAoutTray = false;
                    _this.ipcService.send("resetTrayData", {
                        "code": "A"
                    }); //清除A料仓数据
                    _this.headerinfo.Atraynumber = 0;
                    _this.headerinfo.AtrayStyle = false;
                }
                else {
                    _this.isBoutTray = false;
                    _this.ipcService.send("resetTrayData", {
                        "code": "B"
                    }); //清除料仓数据
                    _this.headerinfo.Btraynumber = 0;
                    _this.headerinfo.BtrayStyle = false;
                }
            });
        });
        window.onbeforeunload = function (event) {
            event.returnValue = false;
            //工作中或者复位中,不能关闭软件
            if (_this.statusops === 8 || _this.statusops === 4) {
                return;
            }
            if (event.returnValue === "false" && _this.closewindow === true) {
                //event.returnValue = false;
                _this.showMessageBox(browserWindow, {
                    type: "warning",
                    message: "是否关闭软件",
                    buttons: ["确定", "取消"],
                    defaultId: 0,
                    cancelId: -1,
                }).then(function (btnIndex) {
                    if (btnIndex === 0) {
                        _this.ipcService.send("windowclose", {});
                    }
                    else {
                        _this.closewindow = true;
                        event.returnValue = false;
                    }
                });
                _this.closewindow = false;
            }
        };
        this.ipcService.on(msgType_1.MSG_TYPE.SEND_TO_MSG, function (response) {
            _this._ngZone.run(function () {
                console.info(response.data);
                if (undefined !== response.data.log) {
                    //this.currenttime=Date.now();      
                    _this.logs.unshift({
                        time: Date.now(), loginfo: response.data.log, style: ""
                    });
                    // this.logs.push({
                    //   time: Date.now(), loginfo: response.data.log
                    // });
                    setTimeout(function () {
                        document.getElementById('js_logDiv').scrollTop = document.getElementById('js_logDiv').scrollHeight;
                    }, 0);
                }
                if (undefined !== response.data.operate) {
                    //this.currenttime=Date.now();      
                    _this.logs.unshift({
                        time: Date.now(), loginfo: response.data.operate, style: ""
                    });
                    setTimeout(function () {
                        document.getElementById('js_logDiv').scrollTop = document.getElementById('js_logDiv').scrollHeight;
                    }, 0);
                }
                if (undefined !== response.data.error) {
                    _this.logs.unshift({
                        time: Date.now(), loginfo: response.data.error, style: "red"
                    });
                    setTimeout(function () {
                        document.getElementById('js_logDiv').scrollTop = document.getElementById('js_logDiv').scrollHeight;
                    }, 0);
                }
            });
        });
        this.ipcService.on("workModel", function (data) {
            _this._ngZone.run(function () {
                //console.info("workModel", data.data);
                _this.keycapsComponent.readconfig(data.data);
                // this.assemblingService.onloadProduct(this.workmodel, data.data);
            });
        });
    };
    AppComponent.prototype.ngAfterViewInit = function () {
        this.ipcService.send("pageready", {});
        this.checkConfig();
        this.maskshow = false;
    };
    AppComponent.prototype.showIo = function (isioshow) {
        this.isShow = isioshow;
        console.info(this.isShow);
    };
    AppComponent.prototype.showconfig = function (configshow) {
        this.configShow = configshow;
    };
    AppComponent.prototype.changepwd = function (pwdpanel) {
        this.changePassword.show();
    };
    AppComponent.prototype.changeStatus = function (newStatus) {
        this.status = newStatus;
    };
    AppComponent.prototype.showfunlog = function (showlogfunction) {
        var _this = this;
        this.isUseShow = showlogfunction;
        //this.logpanel.show();
        if (this.isUseShow === false) {
            this.logpanel.show()
                .then(function (result) {
                _this.logshow = result;
            });
        }
    };
    AppComponent.prototype.showMessageBox = function (browswindow, options) {
        return new Promise(function (resolve, reject) {
            dialog.showMessageBox(browswindow, options, function (btnIndex) {
                resolve(btnIndex);
            });
        });
    };
    AppComponent.prototype.showlogpanel = function (logpanelshow) {
        this.logshow = logpanelshow;
    };
    AppComponent.prototype.showpointpanel = function (Pointshow) {
        this.pointshow = Pointshow;
    };
    AppComponent.prototype.showconfiginfo = function (data) {
        this.configinfo.IP = data[0];
        this.configinfo.MAC_ADDR = data[1];
        this.configinfo.StationNo = data[2];
        this.configinfo.MachineNo = data[3];
        this.configinfo.LineNo = data[4];
        this.configinfo.StationVer = data[5];
        this.configinfo.AOutTrayCount = data[6];
        this.configinfo.BOutTrayCount = data[7];
        this.configinfo.macineType = data[8];
        this.configinfo.CTtime = data[9];
        this.headerinfo.AOutTrayCount = data[6] || 0;
        this.headerinfo.BOutTrayCount = data[7] || 0;
        // this.checkConfig();
    };
    AppComponent.prototype.loginshow = function (logineeshow) {
        //this.loginpanel.hiddenLoginPanel()
        this.loginpanel.showLoginPanel();
        this.maskshow = false;
    };
    AppComponent.prototype.getuserinfo = function (result) {
        //this.loginStatus.role=result.role;
        if (result.role == "admin") {
            this.loginStatus.role = "管理员";
        }
        else {
            this.loginStatus.role = "操作员";
        }
        this.pointpanel.getUserandOpstatus(this.statusops, this.loginStatus.role);
        this.loginStatus.isLogin = result.isLogin;
        this.maskshow = true;
    };
    AppComponent.prototype.outlogin = function (outlogin) {
        this.changePassword.show();
        this.maskshow = false;
    };
    AppComponent.prototype.closepwd = function (closeing) {
        if (closeing === true) {
            this.maskshow = closeing;
        }
        else {
            this.maskshow = false;
            this.loginpanel.showLoginPanel();
        }
    };
    //检查配置是否有空的情况，有的话报警
    AppComponent.prototype.checkConfig = function () {
        var warnInfo = "";
        if (this.configinfo.IP === "") {
            warnInfo += "IP,";
        }
        if (this.configinfo.MAC_ADDR === "") {
            warnInfo += "MAC_ADDR,";
        }
        if (this.configinfo.MachineNo === "") {
            warnInfo += "MachineNo,";
        }
        if (this.configinfo.StationNo === "") {
            warnInfo += "StationNo,";
        }
        if (this.configinfo.LineNo === "") {
            warnInfo += "LineNo,";
        }
        if (this.configinfo.AOutTrayCount === 0) {
            warnInfo += "A仓库出料个数,";
        }
        if (this.configinfo.BOutTrayCount === 0) {
            warnInfo += "B仓库出料个数,";
        }
        if (warnInfo !== "") {
            warnInfo += "参数为空!请设置参数";
        }
        this.warn.loginfo = warnInfo;
    };
    __decorate([
        core_1.ViewChild(assembleing_1.AssembleinfoComponent),
        __metadata("design:type", assembleing_1.AssembleinfoComponent)
    ], AppComponent.prototype, "assembleing", void 0);
    __decorate([
        core_1.ViewChild(change_password_1.ChangePassword),
        __metadata("design:type", change_password_1.ChangePassword)
    ], AppComponent.prototype, "changePassword", void 0);
    __decorate([
        core_1.ViewChild(keycaps_1.KeycapsComponent),
        __metadata("design:type", keycaps_1.KeycapsComponent)
    ], AppComponent.prototype, "keycapsComponent", void 0);
    __decorate([
        core_1.ViewChild(keycapsdetail_1.KeycapDetailComponent),
        __metadata("design:type", keycapsdetail_1.KeycapDetailComponent)
    ], AppComponent.prototype, "keycapsDetail", void 0);
    __decorate([
        core_1.ViewChild(headerinfo_2.HeaderinfoComponent),
        __metadata("design:type", headerinfo_2.HeaderinfoComponent)
    ], AppComponent.prototype, "headerinfomation", void 0);
    __decorate([
        core_1.ViewChild(login_panel_1.LoginlPanel),
        __metadata("design:type", login_panel_1.LoginlPanel)
    ], AppComponent.prototype, "loginpanel", void 0);
    __decorate([
        core_1.ViewChild(logPanel_1.LogPanel),
        __metadata("design:type", logPanel_1.LogPanel)
    ], AppComponent.prototype, "logpanel", void 0);
    __decorate([
        core_1.ViewChild(pointPanel_1.PointPanel),
        __metadata("design:type", pointPanel_1.PointPanel)
    ], AppComponent.prototype, "pointpanel", void 0);
    __decorate([
        core_1.ViewChild(aside_1.AsideComponent),
        __metadata("design:type", aside_1.AsideComponent)
    ], AppComponent.prototype, "asidecomponent", void 0);
    __decorate([
        core_1.ViewChild(pcbcount_1.PcbCountComponent),
        __metadata("design:type", pcbcount_1.PcbCountComponent)
    ], AppComponent.prototype, "pcbCountComponent", void 0);
    AppComponent = __decorate([
        core_1.Component({
            selector: 'root',
            templateUrl: "./webApp/component/root/root.html"
        }),
        __metadata("design:paramtypes", [core_1.NgZone,
            ipc_service_1.IPCService,
            countinfoService_1.countInfoService,
            assemblingService_1.AssemblingService,
            assemblystatusService_1.assemblystatusService,
            TrayinfoService_1.TrayinfoService,
            productionRecordService_1.productionRecordService])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=root.js.map