"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var assembling_1 = require("../common/bean/assembling");
var productIndex = 0;
var AssemblingService = /** @class */ (function () {
    function AssemblingService() {
    }
    AssemblingService.prototype.updateassemblingInfo = function (data, datainfo) {
        data.assemblyKey = datainfo.assemblyKey;
        data.lackKeyCount = datainfo.lackKeyCount;
        data.language = datainfo.language;
        data.timeConsume = datainfo.timeConsume;
        data.type = datainfo.type;
    };
    AssemblingService.prototype.updateheadInfo = function (data, datainfo, type) {
        if (type == 1) {
            data.keycaps[0].language = datainfo[0].language;
            data.keycaps[0].color = datainfo[0].color;
            data.keycaps[0].machineType = datainfo[0].machineType;
            data.keycaps[0].SN = datainfo[0].SN;
            data.keycaps[0].station = datainfo[0].station;
            data.keycaps[0].type = datainfo[0].type;
        }
        else {
            data.keycaps[1].language = datainfo[1].language;
            data.keycaps[1].color = datainfo[1].color;
            data.keycaps[1].machineType = datainfo[1].machineType;
            data.keycaps[1].SN = datainfo[1].SN;
            data.keycaps[1].station = datainfo[1].station;
            data.keycaps[1].type = datainfo[1].type;
        }
    };
    AssemblingService.prototype.assemblinginfo = function (data, datainfo) {
        if (datainfo.code === "A") {
            datainfo.code = "A工位";
            data.codeStation = "A工位";
            data.APCBSN = datainfo.PCBSN || "nosn";
            data.ATraySN = datainfo.TraySN || "noTraysn";
        }
        else {
            data.codeStation = "B工位";
            datainfo.code = "B工位";
            data.BPCBSN = datainfo.PCBSN || "nosn";
            data.BTraySN = datainfo.TraySN || "noTraysn";
        }
        data.jobnumber = datainfo.jobnumber || "";
        data.type = datainfo.type || "";
    };
    AssemblingService.prototype.productdetailinfo = function (data, datainfo) {
        data.productdetail = new assembling_1.productdetail();
        if (datainfo.code === "A") {
            data.productdetail.codeStation = "A工位";
        }
        else {
            data.productdetail.codeStation = "B工位";
        }
        data.productdetail.PCBSN = datainfo.PCBSN || "nosn";
        data.productdetail.TraySN = datainfo.TraySN || "noTraysn";
        data.productdetail.time = datainfo.time;
        data.productdetail.jobnumber = datainfo.jobnumber || "";
        data.productdetail.type = datainfo.type || "";
        data.productdetail.index = productIndex + 1;
        productIndex++;
        data.detailproduct.unshift(data.productdetail);
        // if(data.detailproduct.length>5){
        //     data.detailproduct.splice(data.detailproduct.length-1,1);
        // }
    };
    AssemblingService.prototype.onloadProduct = function (data, datainfo) {
        data.detailproduct = datainfo;
        data.detailproduct.forEach(function (item) {
            item.index++;
        });
    };
    AssemblingService = __decorate([
        core_1.Injectable()
    ], AssemblingService);
    return AssemblingService;
}());
exports.AssemblingService = AssemblingService;
//# sourceMappingURL=assemblingService.js.map