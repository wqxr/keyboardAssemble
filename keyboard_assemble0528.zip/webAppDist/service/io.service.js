"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var IOData_1 = require("../common/bean/IOData");
var IOService = /** @class */ (function () {
    function IOService() {
        this.ioList = IOData_1.IOList;
        this.cards = [];
        // this.cards=new Card();
        for (var i = 0; i < 17; i++) {
            this.cards[i] = new IOData_1.Card();
        }
        // for(let i = 0 ; i < 11; ++i){
        //     this.cards[i] = new Card();
        //     this.cards[i].cardId = i;
        // }
    }
    IOService.prototype.parseIntIo = function (carId, ioStr, type) {
        var ioVal;
        var varStr = ioStr.toString(2);
        while (varStr.length < 16) {
            varStr = '0' + varStr;
        }
        for (var i = 0; i < varStr.length; i++) {
            var card = this.cards[carId];
            card.cardId = carId;
            if (type === 0) {
                card.input[i] = parseInt(varStr[15 - i]);
            }
            else {
                card.output[i] = parseInt(varStr[15 - i]);
            }
        }
        this.updateIoStatus(type);
    };
    //card.output[i]=parseInt(varStr[15-i]);
    // return varStr;
    // updateCardIo(ioStatus:string){
    //     let ioStr:string="";
    //     for(let i = 0 ; i < ioStatus.length; ++i){
    //         let val = ioStatus[i];
    //         let valStr = val.toString(2);
    //         while( valStr.length < 16 ){
    //             valStr = '0' + valStr;
    //         }
    //         for(let i=0;i<ioStr.length;++i){
    //             let card=this.cards;
    //             card.input[i]=parseInt(ioStr[i]);
    //         }
    //     }
    //     this.updateIoStatus();
    // }
    IOService.prototype.updateIoStatus = function (type) {
        var _this = this;
        for (var i = 0; i < this.ioList.length; ++i) {
            var ioPanelItem = this.ioList[i];
            ioPanelItem.reactIOList.forEach(function (io) {
                _this.upDateIo(io, type);
            });
            ioPanelItem.nozzleList.forEach(function (nozzle) {
                _this.upDateIo(nozzle.control, type);
                _this.upDateIo(nozzle.react, type);
                _this.upDateIo(nozzle.controlreact, type);
            });
            ioPanelItem.cylinderIOList.forEach(function (cylinder) {
                _this.upDateIo(cylinder.activity, type);
                _this.upDateIo(cylinder.original, type);
                _this.upDateIo(cylinder.activityReact, type);
                _this.upDateIo(cylinder.originalReact, type);
            });
            ioPanelItem.otherIoList.forEach(function (io) {
                _this.upDateIo(io, type);
            });
        }
    };
    IOService.prototype.upDateIo = function (io, type) {
        if (!io) {
            return;
        }
        if (io.type === IOData_1.IOType.IN && this.cards && type === 0) {
            io.value = this.cards[io.cardId].input[io.index];
        }
        else if (io.type === IOData_1.IOType.OUT && this.cards && type === 1) {
            io.value = this.cards[io.cardId].output[io.index];
        }
    };
    IOService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], IOService);
    return IOService;
}());
exports.IOService = IOService;
//# sourceMappingURL=io.service.js.map