export class Config{
    IP: string;
    MAC_ADDR: string;
    LineNo: string;
    StationNo: string;
    MachineNo: string;
    StationVer:string;
    OutTrayCount:string;
    constructor(){
        this.IP = "";
        this.MAC_ADDR = "";
        this.LineNo = "";
        this.StationNo = "";
        this.MachineNo = "";
        this.StationVer = "";
        this.OutTrayCount = "";
    }
}
