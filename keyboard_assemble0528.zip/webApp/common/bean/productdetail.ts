export class productDetail{
    public codeStation:string="";
    public APCBSN:string="";
    public ATraySN:string="";
    public BPCBSN:string="";
    public BTraySN:string="";
    public  type:string="";
    public jobnumber:string="";
    public keynow:string="";

}