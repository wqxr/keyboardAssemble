import { Injectable } from '@angular/core';
import {productDetail} from "../common/bean/productdetail"

@Injectable()
export class productionRecordService{
  updateheadInfo(data:productDetail,datainfo:any){
      
  }
}